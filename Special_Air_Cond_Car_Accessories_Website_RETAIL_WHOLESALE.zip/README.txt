SPECIAL AIR-COND & CAR ACCESSORIES CENTRE - WEBSITE

Open index.html in a modern browser. Keep the assets folder beside index.html so all photographs load.

This version groups the services into five main departments: Car Air-Conditioning; Car Accessories & Multimedia; Electrical & Lighting; Interior & Exterior Accessories; Diagnostics & Troubleshooting.

Contact: 011-5352 1899
Address: 9 Jalan Manis 1/1, Taman Manis 1, 86400 Parit Raja, Batu Pahat, Johor, Malaysia
